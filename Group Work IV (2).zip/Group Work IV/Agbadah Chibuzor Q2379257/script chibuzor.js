document.addEventListener("DOMContentLoaded", function() {
    // Define chart dimensions and margins
    const width = 1200;
    const height = 400;
    const margin = { top: 50, right: 6, bottom: 50, left: 150 };
    const barPadding = 0.5;

    // Create SVG element
    const svg = d3.select("#svg-container");

    // Rank data function
    function rankData(data, accessor) {
        const rankedData = Array.from(data, d => ({ ...d }));
        rankedData.sort((a, b) => d3.descending(accessor(a), accessor(b)));
        for (let i = 0; i < rankedData.length; ++i) {
            rankedData[i].rank = i;
        }
        return rankedData;
    }

    // Load the dataset
    d3.json("iv_file.json").then(async function(data) {
        // Group the data by year
        const nestedData = d3.group(data, d => d.Year);

        // Extract unique years from the data
        const years = Array.from(nestedData.keys());

        // Define color scale for different job roles
        const colorScale = d3.scaleOrdinal(d3.schemeCategory10);

        // Compute the maximum average salary across all years
        const maxSalary = d3.max(data, d => d.AverageSalary);

        // Define scale functions
        const xScale = d3.scaleLinear().domain([0, maxSalary]).range([margin.left, width - margin.right]);

        // Define axes
        const xAxis = d3.axisTop(xScale)
            .ticks(5)
            .tickSize(-height + margin.top + margin.bottom)
            .tickFormat(d3.format("$.2s"));

        // Rank the data based on average salary
        const rankedData = rankData(data, d => d.AverageSalary);

        // Create ticker group
        const tickerGroup = svg.append("text")
            .attr("class", "ticker")
            .attr("x", width - margin.right)
            .attr("y", height - margin.bottom + 30)
            .attr("text-anchor", "end")
            .attr("font-size", 30);

        // Format number as whole numbers
        const formatNumber = d3.format(",d");

        // Generator function for animation
        async function* chartRace() {
            for (const year of years) {
                const transition = svg.transition()
                    .duration(7000)
                    .ease(d3.easeLinear);

                const keyframe = {
                    year,
                    data: nestedData.get(year).sort((a, b) => b.AverageSalary - a.AverageSalary) || []
                };

                // Update bars
                const bars = svg.selectAll(".bar")
                    .data(keyframe.data, d => d.Job_Roles);

                bars.enter()
                    .append("rect")
                    .attr("class", "bar")
                    .attr("x", margin.left)
                    .attr("y", (d, i) => margin.top + i * ((height - margin.bottom - margin.top) / keyframe.data.length + barPadding * (keyframe.data.length - 1)))
                    .attr("width", margin.left + 70)
                    .attr("height", (height - margin.bottom - margin.top) / keyframe.data.length)
                    .attr("fill", d => colorScale(d.Job_Roles))
                    .style("pointer-events", "none") // Disable pointer events for bars
                    .merge(bars)
                    .transition(transition)
                    .ease(d3.easeQuadIn) // Add easing function
                    .attr("x", margin.left)
                    .attr("y", (d, i) => margin.top + i * ((height - margin.bottom - margin.top) / keyframe.data.length + barPadding * (keyframe.data.length - 1)))
                    .attr("width", d => xScale(d.AverageSalary) - margin.left)
                    .attr("height", (height - margin.bottom - margin.top) / keyframe.data.length);

                bars.exit().remove();

                // Append axes to SVG
                const xAxisGroup = svg.append("g")
                    .attr("class", "x-axis")
                    .attr("transform", `translate(0, ${margin.top})`)
                    .call(xAxis);

                // Modify the font size of the x-axis ticks
                xAxisGroup.selectAll(".tick text")
                    .attr("font-size", 15); // Adjust the font size as needed

                xAxisGroup.select(".domain").remove(); // Remove the domain line

                xAxisGroup.selectAll(".tick line").attr("stroke", "#d1d2d3"); // Change tick line color

                // Update average salary labels attached to bars
                const averageLabels = svg.selectAll(".value")
                    .data(keyframe.data, d => d.Job_Roles);

                averageLabels.enter()
                    .append("text")
                    .attr("class", "value")
                    .attr("x", d => margin.left + 90)
                    .attr("y", (d, i) => Math.max(margin.top + i * ((height - margin.bottom - margin.top) / keyframe.data.length + barPadding * (keyframe.data.length - 1)) + ((height - margin.bottom - margin.top) / keyframe.data.length) / 2, margin.top)) // Adjusted position
                    .attr("text-anchor", "start")
                    .attr("alignment-baseline", "middle")
                    .attr("font-size", 20)
                    .text(d => "$" + formatNumber(d.AverageSalary))
                    .merge(averageLabels)
                    .transition(transition)
                    .ease(d3.easeQuadIn) // Add easing function
                    .duration(7000)
                    .attrTween("x", function(d) {
                        const currentX = this.__currentX || (margin.left + 90); // Get current x-coordinate or default to initial position
                        const newX = Math.max(margin.left, xScale(d.AverageSalary) - 85);
                        const interpolateX = d3.interpolate(currentX, newX);
                        // Store current x-coordinate for next transition
                        this.__currentX = newX;
                        return function(t) {
                            return interpolateX(t);
                        };
                    })
                    .attr("y", (d, i) => Math.max(margin.top + i * ((height - margin.bottom - margin.top) / keyframe.data.length + barPadding * (keyframe.data.length - 1)) + ((height - margin.bottom - margin.top) / keyframe.data.length) / 2, margin.top)) // Adjusted position
                    .tween("text", function(d) { // Transition text content
                        var i = d3.interpolate(0, d.AverageSalary);
                        return function(t) {
                            d3.select(this).text("$" + formatNumber(i(t)));
                        };
                    });

                averageLabels.exit().remove();

                // Update job role labels
                const labels = svg.selectAll(".label")
                    .data(keyframe.data, d => d.Job_Roles);

                labels.enter()
                    .append("text")
                    .attr("class", "label")
                    .attr("x", margin.left)
                    .attr("y", (d, i) => margin.top + i * ((height - margin.bottom - margin.top) / keyframe.data.length + barPadding * (keyframe.data.length - 1)) + ((height - margin.bottom - margin.top) / keyframe.data.length) / 2)
                    .attr("text-anchor", "start")
                    .attr("alignment-baseline", "middle")
                    .attr("font-size", 15)
                    .text(d => d.Job_Roles)
                    .merge(labels)
                    .transition(transition)
                    .ease(d3.easeQuadIn) // Add easing function
                    .duration(7000)
                    .attrTween("x", function(d) {
                        const currentX = parseFloat(this.getAttribute("x"));
                        const interpolateX = d3.interpolate(currentX, Math.max(margin.left, xScale(d.AverageSalary) - 180));
                        return function(t) {
                            return interpolateX(t);
                        };
                    })
                    .attr("y", (d, i) => margin.top + i * ((height - margin.bottom - margin.top) / keyframe.data.length + barPadding * (keyframe.data.length - 1)) + ((height - margin.bottom - margin.top) / keyframe.data.length) / 2)
                    .style("opacity", d => (xScale(d.AverageSalary) > margin.left ? 1 : 0)); // Hide labels if corresponding bar is not visible

                labels.exit().remove();

                // Update ticker
                tickerGroup.transition(transition).text(`Year: ${keyframe.year}`);

                await transition.end();

                if (isPaused) {
                    // Pause animation if paused
                    while (isPaused) {
                        await new Promise(resolve => setTimeout(resolve, 100));
                    }
                }

                yield;
            }
        }

        // Animate the chart race
        let chartGenerator = chartRace();
        let isPaused = false; // Variable to track pause state
        let currentFrame; // Variable to store interval reference for replay

        // Start animation automatically when the page is loaded
        currentFrame = setInterval(() => {
            const { done } = chartGenerator.next();
            if (done) clearInterval(currentFrame);
        }, 100);

        // Add event listener for replay button
        document.getElementById("replay-button").addEventListener("click", function() {
            // Restart animation
            if (currentFrame) clearInterval(currentFrame);
            isPaused = false;
            chartGenerator = chartRace();
            currentFrame = setInterval(() => {
                const { done } = chartGenerator.next();
                if (done) clearInterval(currentFrame);
            }, 100);
        });

        // Add event listener for pause button
        document.getElementById("pause-button").addEventListener("click", function() {
            // Toggle pause state
            isPaused = !isPaused;
        });
    });
});
