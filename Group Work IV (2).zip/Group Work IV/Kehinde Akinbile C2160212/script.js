// Log a message to the console when the script is loaded
console.log("Script loaded");

// Declare global variables
var bubbles;
var simulation;
var data;

// Load JSON data asynchronously using D3.js
d3.json("csvjson.json").then(function (jsonData) {
  data = jsonData; // Store the loaded JSON data in a variable
  console.log("Data loaded:", data); // Log the loaded data to the console

  var width = 800; // Width of the SVG container
  var height = 600; // Height of the SVG container
  var colorScale = d3.scaleOrdinal(d3.schemeCategory10); // Color scale for bubbles
  var radiusScale = d3.scaleLinear().range([10, 40]); // Scale for bubble radius

  var svg = d3.select("#chart") // Select the chart container
    .append("svg") // Append an SVG element
    .attr("width", width) // Set the width of the SVG
    .attr("height", height); // Set the height of the SVG

  // Adding title text inside the SVG
  svg.append("text")
    .attr("x", width / 2)
    .attr("y", 30)
    .attr("text-anchor", "middle")
    .attr("font-size", "20px")
    .attr("font-weight", "bold");

  var tooltip = d3.select("body").append("div") // Append a tooltip container to the body
    .attr("class", "tooltip") // Set the class for styling
    .style("opacity", 0); // Initially hide the tooltip

  processData(); // Call the processData function to process the data

  // Function to process and visualize the data
  function processData() {
    // Group data by Year, Job Role, and Company Location
    var avgSalaryByYearRoleCountry = Array.from(
      d3.group(data, d => `${d.Year}-${d["Job Role"]}-${d["Company Location"]}`),
      ([key, value]) => ({ key, value: d3.mean(value, d => d.Salary), details: value })
    );

    console.log("Average salary data:", avgSalaryByYearRoleCountry); // Log the processed data

    // Extract unique job roles from the data
    var uniqueJobRoles = Array.from(new Set(data.map(d => d["Job Role"])));
    colorScale.domain(uniqueJobRoles); // Set domain for color scale
    radiusScale.domain([d3.min(avgSalaryByYearRoleCountry, d => d.value), d3.max(avgSalaryByYearRoleCountry, d => d.value)]); // Set domain for radius scale

    // Create force simulation for bubble layout
    simulation = d3.forceSimulation(avgSalaryByYearRoleCountry)
      .force("x", d3.forceX().strength(0.05).x(width / 2))
      .force("y", d3.forceY().strength(0.1).y(height / 2))
      .force("collide", d3.forceCollide().radius(d => radiusScale(d.value) + 2).iterations(2))
      .on("tick", ticked); // Define tick function for simulation

    // Create SVG circles (bubbles) for each data point
    bubbles = svg.selectAll(".bubble")
      .data(avgSalaryByYearRoleCountry)
      .enter().append("circle")
      .attr("class", "bubble")
      .attr("r", function (d) { return radiusScale(d.value); })
      .style("fill", function (d) { return colorScale(d.key.split("-")[1]); })
      .on("mouseover", function (event, d) {
        // Highlight bubble and display tooltip on mouseover
        d3.selectAll(".bubble").style("opacity", 0.3);
        d3.select(this).style("opacity", 1);
        tooltip.transition().duration(200).style("opacity", .9);
        tooltip.html(`Job Role: ${d.key.split("-")[1]}<br>Salary: $${d.value.toFixed(2)}<br>Year: ${d.key.split("-")[0]}<br>Country: ${d.key.split("-")[2]}`)
          .style("left", (event.pageX) + "px")
          .style("top", (event.pageY - 28) + "px");
      })
      .on("mouseout", function () {
        // Restore opacity and hide tooltip on mouseout
        d3.selectAll(".bubble").style("opacity", 1);
        tooltip.transition().duration(500).style("opacity", 0);
      })
      .call(d3.drag() // Enable drag behavior for bubbles
        .on("start", dragstarted)
        .on("drag", dragged)
        .on("end", dragended));

    // Add legends for different job roles
    var legend = svg.selectAll(".legend")
      .data(uniqueJobRoles)
      .enter().append("g")
      .attr("class", "legend")
      .attr("transform", function(d, i) { return `translate(0, ${i * 20 + 20})`; });

    legend.append("rect")
      .attr("x", width - 24)
      .attr("width", 18)
      .attr("height", 18)
      .style("fill", function(d) { return colorScale(d); });

    legend.append("text")
      .attr("x", width - 30)
      .attr("y", 9)
      .attr("dy", ".35em")
      .style("text-anchor", "end")
      .text(function(d) { return d; });

    // Filter bubbles based on legend selection
    legend.on("click", function(event, selectedJobRole) {
      bubbles.style("display", function(d) {
        return d.key.split("-")[1] === selectedJobRole ? "block" : "none";
      });
    });
  }

  // Function to update bubble visibility based on selected year
  function updateVisualization() {
    var selectedYear = document.getElementById("year").value;
    bubbles.style("display", function (d) {
      return selectedYear === "all" || d.key.split("-")[0] === selectedYear ? "block" : "none";
    });
  }

  // Function to reset bubble visibility
  function resetVisualization() {
    bubbles.style("display", "block");
  }

  // Drag functions for simulating bubble dragging
  function dragstarted(event, d) {
    if (!event.active) simulation.alphaTarget(0.3).restart();
    d.fx = d.x;
    d.fy = d.y;
  }

  function dragged(event, d) {
    d.fx = event.x;
    d.fy = event.y;
  }

  function dragended(event, d) {
    if (!event.active) simulation.alphaTarget(0);
    d.fx = null;
    d.fy = null;
  }
});
