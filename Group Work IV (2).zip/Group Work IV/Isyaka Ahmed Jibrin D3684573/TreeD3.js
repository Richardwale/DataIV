// Load the JSON data asynchronously using D3.js
d3.json("TreeData.json")
// Handle the loaded data
.then(function(treeData) {
    // Set the dimensions and margins of the diagram
    var margin = {top: 20, right: 90, bottom: 30, left: 150}, // Define margins
        width = 1200 - margin.left - margin.right, // Define SVG width
        height = 800 - margin.top - margin.bottom; // Define SVG height

    // Define custom colors for different levels
    var color = d3.scaleOrdinal() //function to create a scale mapping depth levels (0, 1, 2, 3) to specific colors ("red", "blue", "purple", "green").
        .domain([0, 1, 2, 3]) // Depth levels
        .range(["red", "blue", "purple", "green"]); 

    // Append the SVG object to the body of the page
    var svg = d3.select("svg") // Select the SVG element
        .attr("width", width + margin.right + margin.left) // Set SVG width including margins
        .attr("height", height + margin.top + margin.bottom) // Set SVG height including margins
        .append("g") // Append a group element to the SVG.  
                .attr("transform", "translate(" + margin.left + "," + margin.top + ")"); // Translate the group

    // Initialize variables i, duration, and root.
    var i = 0, // integer variable used as a counter. It Initialize counter variable.  
        duration = 750, // Animation duration (in milliseconds) for animations.
        root; // Define root node. 

    // Declare a tree layout and assign the size. 
    var treemap = d3.tree().size([height, width]);

    // Assign parent, children, height, depth
    root = d3.hierarchy(treeData, function(d) { return d.children; }); 
    root.x0 = height / 2;
    root.y0 = 0;

    // Collapse after the second level
    root.children.forEach(collapse);

    // Update the tree
    update(root);

    // Function to collapse the node and all its children
    function collapse(d) {
        if (d.children) {
            d._children = d.children;
            d._children.forEach(collapse);
            d.children = null;
        }
    }

    // Function to update the tree
    function update(source) {
        // Compute the new tree layout.
        var treeData = treemap(root);

        // Compute the new tree layout.
        var nodes = treeData.descendants(),
            links = treeData.descendants().slice(1);

        // Normalize for fixed-depth.
        nodes.forEach(function(d) {
            d.y = d.depth * 180
        });

        // ****************** Nodes section ***************************

        // Update the nodes...
        var node = svg.selectAll('g.node')
            .data(nodes, function(d) {
                return d.id || (d.id = ++i);
            });

        // Enter any new modes at the parent's previous position.
        var nodeEnter = node.enter().append('g')
            .attr('class', 'node')
            .attr("transform", function(d) {
                return "translate(" + source.y0 + "," + source.x0 + ")";
            })
            .on('click', click);

        // Add Circle for the nodes
        var circles = nodeEnter.append('circle')
            .attr('class', function(d) {
                return 'node ' + d.data.className + ' tooltip'; // Append tooltip class here
            })
            .attr('r', 1e-6)
            .style("fill", function(d) {
                return color(d.depth); // Use depth to determine the color
            });

        //Append tooltip to circles
        circles.append("title")
            .text(function(d) {
                if (d.data.name.includes("Data Science")) {
                    return "3.755 jobs"; // Set tooltip text for Data Science nodes
                } else if (d.data.name.includes("Research Engineer")) {
                    return "37 Research Engineer jobs"; // Set tooltip text for Research Engineer nodes
                } else if (d.data.name.includes("Research Scientist")) {
                    return "82 Research Scientists Jobs"; // Set tooltip text for Research Scientist nodes
                } else if (d.data.name.includes("Software Data Engineer")) {
                    return "2 Software Data Engineer"; // Set tooltip text for Software Data Engineer nodes
                } else if (d.data.name.includes("Staff Data Analyst")) {
                    return "1 Staff Data Analyst"; // Set tooltip text for Staff Data Analyst nodes
                } else if (d.data.name.includes("Staff Data Scientist")) {
                    return "1 Staff Data Scientist"; // Set tooltip text for Staff Data Scientist nodes
                } else if (d.data.name.includes("On-site")) {
                    // Check the parent node to determine the job type and set the tooltip accordingly
                    var parent = d.parent.data.name;
                    if (parent === "Research Scientist") {
                        return "Remote Ratio 75"; // Tooltip text for Research Scientist nodes
                    } else if (parent === "Research Engineer") {
                        return "Remote Ratio 23"; // Tooltip text for Research Engineer nodes
                    } else if (parent === "Software Data Engineer") {
                        return "Remote Ratio 2"; // Tooltip text for Software Data Engineer nodes
                    } else if (parent === "Staff Data Analyst" || parent === "Staff Data Scientist") {
                        return "Remote Ratio 1"; // Tooltip text for Staff Data Analyst and Staff Data Scientist nodes
                    } else {
                        return ""; 
                    }
                } else {
                    return ""; 
                }
            });
        // Add labels for the nodes
        nodeEnter.append('text')
            .attr("dy", "-1.5em") // Move the text up above the circle
            .attr("text-anchor", "middle") // Center the text horizontally
            .text(function(d) {
                return d.data.name;
            });

        // UPDATE
        var nodeUpdate = nodeEnter.merge(node);

        // Transition to the proper position for the node
        nodeUpdate.transition()
            .duration(duration)
            .attr("transform", function(d) {
                return "translate(" + d.y + "," + d.x + ")";
            });

        // Update the node attributes and style
        nodeUpdate.select('circle.node')
            .attr('r', 10)
            .style("fill", function(d) {
                return color(d.depth); // Use depth to determine the color
            })
            .attr('cursor', 'pointer');

        // Remove any exiting nodes
        //This section of code removes any nodes that are exiting the visualization
        var nodeExit = node.exit().transition()
            .duration(duration)
            .attr("transform", function(d) {
                return "translate(" + source.y + "," + source.x + ")";
            })
            .remove();

        // On exit reduce the node circles size to 0
        //This part of the code reduces the radius of the circle representing the exiting nodes to zero. It's a transition effect that makes the nodes gradually disappear as they are removed from the visualization.
        nodeExit.select('circle')
            .attr('r', 1e-6);

        // On exit reduce the opacity of text labels
        //This line of code reduces the opacity of the text labels associated with the exiting nodes to nearly zero. 
        nodeExit.select('text')
            .style('fill-opacity', 1e-6);

        // ****************** links section ***************************

        // Update the links...
        //This code selects all existing link paths in the SVG container and binds them to the data representing the links between nodes in the tree layout
        var link = svg.selectAll('path.link')
            .data(links, function(d) {
                return d.id;
            });

        // Enter any new links at the parent's previous position.
        var linkEnter = link.enter().insert('path', "g")
            .attr("class", "link")
            .attr('d', function(d) {
                var o = {
                    x: source.x0,
                    y: source.y0
                }
                return diagonal(o, o)
            })
            .style("stroke", function(d) {
                return color(d.parent.depth);
            }); // Set the link color

        // UPDATE
        //This section of the code updates the existing links by merging them with any new links that were added
        var linkUpdate = linkEnter.merge(link);

        // Transition back to the parent element position
        //The duration of the transition is set to the value of the `duration` variable, ensuring a smooth visual update.
        linkUpdate.transition()
            .duration(duration)
            .attr('d', function(d) {
                return diagonal(d, d.parent)
            });

        // Remove any exiting links
        //This section of the code removes any links that are no longer present in the updated data.  
        var linkExit = link.exit().transition()
            .duration(duration)
            .attr('d', function(d) {
                var o = {
                    x: source.x,
                    y: source.y
                }
                return diagonal(o, o)
            })
            .remove();

        // Store the old positions for transition.
        //This is done to prepare for transitioning smoothly from the old positions to the new positions during the update process.
        nodes.forEach(function(d) {
            d.x0 = d.x;
            d.y0 = d.y;
        });

        // Creates a curved (diagonal) path from parent to the child nodes
        //This function generates a curved (diagonal) path from a parent node (`s`) to a child node (`d`)
        //It uses SVG path commands to create a Bezier curve (`C`) that smoothly connects the two points
        //The curve starts at the parent's `y` and `x` coordinates, then moves to a control point halfway between the parent and child nodes horizontally, 
        //with the parent's `x` coordinate, and stays at the parent's `y` coordinate. 
        function diagonal(s, d) {
            return `M ${s.y} ${s.x}
                    C ${(s.y + d.y) / 2} ${s.x},
                        ${(s.y + d.y) / 2} ${d.x},
                        ${d.y} ${d.x}`;
        }

        // Toggle children on click.  
        function click(event, d) {
            if (d.children) {
                d._children = d.children;
                d.children = null;
            } else {
                d.children = d._children;
                d._children = null;
            }
            update(d);
        }
    }

    // Reset function 
    function reset() {

        // Collapse the tree
        root.children.forEach(collapse);
        update(root);
    }

    // Add event listener for the reset button in the HTML document.
    document.getElementById("resetButton").addEventListener("click", reset);

     // Filtering functionality
    document.getElementById('jobType').addEventListener('change', function() {
        var selectedJobType = this.value;
        var nodes = svg.selectAll('.node text');
        nodes.style('display', function(d) {
            if (selectedJobType === 'all') {
                return 'block';
            } else if (selectedJobType === '2020') {
                // Display nodes for 'Research Engineer' and 'Research Scientist' along with their respective on-site nodes
                return (d.data.name.includes('Research Engineer') || d.data.name.includes('Research Scientist') || (d.data.name.includes('On-site') && (d.parent && (d.parent.data.name === 'Research Engineer' || d.parent.data.name === 'Research Scientist')))) ? 'block' : 'none';
            } else {
                // Display nodes based on the selected job type (optimized for readability and efficiency)
                return (selectedJobType === 'all' || d.data.name.includes(selectedJobType) || (d.data.name.includes("On-site") && d.parent && d.parent.data.name.includes(selectedJobType))) ? 'block' : 'none';
            }
        });
    });

})
.catch(function(error) {
    // Handle errors if the JSON file fails to load
    d3.select('.error').style('visibility', 'visible').text("There was an error fetching the data: " + error);
});
