import pandas as pd
import json

# Read the CSV file
df = pd.read_csv('data3.csv')

# Define hierarchy levels
industry_levels = df['Industry'].unique()
experience_levels = df['Experience Level'].unique()
job_roles = df['Job Role'].unique()

# Create hierarchy structure
data = {'name': "Data Science Roles", 'average_salary': 0, 'children': []}

# Calculate overall average salary
total_salary = df['Salary'].sum()
total_count = df.shape[0]
overall_average_salary = total_salary / total_count if total_count > 0 else 0
data['average_salary'] = overall_average_salary

for industry in industry_levels:
    industry_data = {'name': industry, 'average_salary': 0, 'children': []}
    industry_df = df[df['Industry'] == industry]
    industry_total_salary = industry_df['Salary'].sum()
    industry_total_count = industry_df.shape[0]
    industry_average_salary = industry_total_salary / industry_total_count if industry_total_count > 0 else 0
    industry_data['average_salary'] = industry_average_salary

    for experience in experience_levels:
        experience_data = {'name': experience, 'average_salary': 0, 'children': []}
        experience_df = industry_df[industry_df['Experience Level'] == experience]
        experience_total_salary = experience_df['Salary'].sum()
        experience_total_count = experience_df.shape[0]
        experience_average_salary = experience_total_salary / experience_total_count if experience_total_count > 0 else 0
        experience_data['average_salary'] = experience_average_salary

        for role in job_roles:
            role_count = len(df[(df['Industry'] == industry) & (df['Experience Level'] == experience) & (df['Job Role'] == role)])
            if role_count > 0:
                role_data = {'name': role, 'count': role_count, 'average_salary': 0}
                role_df = experience_df[experience_df['Job Role'] == role]
                role_total_salary = role_df['Salary'].sum()
                role_average_salary = role_total_salary / role_count if role_count > 0 else 0
                role_data['average_salary'] = role_average_salary
                experience_data['children'].append(role_data)

        if experience_data['children']:
            industry_data['children'].append(experience_data)

    if industry_data['children']:
        data['children'].append(industry_data)

# Write data to JSON file
with open('hierarchy_with_salary.json', 'w') as json_file:
    json.dump(data, json_file, indent=4)
